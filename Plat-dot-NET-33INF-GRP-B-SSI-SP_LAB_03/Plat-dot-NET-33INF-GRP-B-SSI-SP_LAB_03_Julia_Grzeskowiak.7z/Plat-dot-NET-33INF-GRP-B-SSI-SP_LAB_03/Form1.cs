namespace Plat_dot_NET_33INF_GRP_B_SSI_SP_LAB_03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
