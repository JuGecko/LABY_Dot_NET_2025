﻿namespace Zadanie_04
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button0 = new Button();
            buttonPoint = new Button();
            buttonClear = new Button();
            buttonDivision = new Button();
            buttonMultiplication = new Button();
            buttonPlus = new Button();
            buttonMinus = new Button();
            buttonEquals = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button1.Location = new Point(13, 235);
            button1.Name = "button1";
            button1.Size = new Size(79, 65);
            button1.TabIndex = 0;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button2.Location = new Point(98, 235);
            button2.Name = "button2";
            button2.Size = new Size(79, 65);
            button2.TabIndex = 1;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button3.Location = new Point(183, 235);
            button3.Name = "button3";
            button3.Size = new Size(79, 65);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button4.Location = new Point(13, 164);
            button4.Name = "button4";
            button4.Size = new Size(79, 65);
            button4.TabIndex = 3;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button5.Location = new Point(98, 164);
            button5.Name = "button5";
            button5.Size = new Size(79, 65);
            button5.TabIndex = 4;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button6.Location = new Point(183, 164);
            button6.Name = "button6";
            button6.Size = new Size(79, 65);
            button6.TabIndex = 5;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button7.Location = new Point(13, 93);
            button7.Name = "button7";
            button7.Size = new Size(79, 65);
            button7.TabIndex = 6;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button8.Location = new Point(98, 93);
            button8.Name = "button8";
            button8.Size = new Size(79, 65);
            button8.TabIndex = 7;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button9.Location = new Point(183, 93);
            button9.Name = "button9";
            button9.Size = new Size(79, 65);
            button9.TabIndex = 8;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            // 
            // button0
            // 
            button0.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            button0.Location = new Point(12, 306);
            button0.Name = "button0";
            button0.Size = new Size(79, 65);
            button0.TabIndex = 9;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = true;
            button0.Click += button0_Click;
            // 
            // buttonPoint
            // 
            buttonPoint.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonPoint.Location = new Point(97, 306);
            buttonPoint.Name = "buttonPoint";
            buttonPoint.Size = new Size(79, 65);
            buttonPoint.TabIndex = 10;
            buttonPoint.Text = ".";
            buttonPoint.UseVisualStyleBackColor = true;
            buttonPoint.Click += buttonPoint_Click;
            // 
            // buttonClear
            // 
            buttonClear.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonClear.Location = new Point(182, 306);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(79, 65);
            buttonClear.TabIndex = 11;
            buttonClear.Text = "C";
            buttonClear.UseVisualStyleBackColor = true;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonDivision
            // 
            buttonDivision.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonDivision.Location = new Point(344, 93);
            buttonDivision.Name = "buttonDivision";
            buttonDivision.Size = new Size(79, 65);
            buttonDivision.TabIndex = 12;
            buttonDivision.Text = "/";
            buttonDivision.UseVisualStyleBackColor = true;
            buttonDivision.Click += buttonDivision_Click;
            // 
            // buttonMultiplication
            // 
            buttonMultiplication.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonMultiplication.Location = new Point(344, 164);
            buttonMultiplication.Name = "buttonMultiplication";
            buttonMultiplication.Size = new Size(79, 65);
            buttonMultiplication.TabIndex = 13;
            buttonMultiplication.Text = "*";
            buttonMultiplication.UseVisualStyleBackColor = true;
            buttonMultiplication.Click += buttonMultiplication_Click;
            // 
            // buttonPlus
            // 
            buttonPlus.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonPlus.Location = new Point(344, 235);
            buttonPlus.Name = "buttonPlus";
            buttonPlus.Size = new Size(79, 65);
            buttonPlus.TabIndex = 14;
            buttonPlus.Text = "+";
            buttonPlus.UseVisualStyleBackColor = true;
            buttonPlus.Click += buttonPlus_Click;
            // 
            // buttonMinus
            // 
            buttonMinus.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonMinus.Location = new Point(344, 306);
            buttonMinus.Name = "buttonMinus";
            buttonMinus.Size = new Size(79, 65);
            buttonMinus.TabIndex = 15;
            buttonMinus.Text = "-";
            buttonMinus.UseVisualStyleBackColor = true;
            buttonMinus.Click += buttonMinus_Click;
            // 
            // buttonEquals
            // 
            buttonEquals.Font = new Font("Yu Gothic Medium", 13.8F, FontStyle.Bold);
            buttonEquals.Location = new Point(13, 377);
            buttonEquals.Name = "buttonEquals";
            buttonEquals.Size = new Size(249, 65);
            buttonEquals.TabIndex = 16;
            buttonEquals.Text = "=";
            buttonEquals.UseVisualStyleBackColor = true;
            buttonEquals.Click += buttonEquals_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Yu Gothic Medium", 18F, FontStyle.Bold, GraphicsUnit.Point, 238);
            textBox1.Location = new Point(12, 18);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(411, 56);
            textBox1.TabIndex = 17;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(447, 487);
            Controls.Add(textBox1);
            Controls.Add(buttonEquals);
            Controls.Add(buttonMinus);
            Controls.Add(buttonPlus);
            Controls.Add(buttonMultiplication);
            Controls.Add(buttonDivision);
            Controls.Add(buttonClear);
            Controls.Add(buttonPoint);
            Controls.Add(button0);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button0;
        private Button buttonPoint;
        private Button buttonClear;
        private Button buttonDivision;
        private Button buttonMultiplication;
        private Button buttonPlus;
        private Button buttonMinus;
        private Button buttonEquals;
        private TextBox textBox1;
    }
}
